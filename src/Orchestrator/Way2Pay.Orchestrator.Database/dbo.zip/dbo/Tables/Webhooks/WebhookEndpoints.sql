CREATE TABLE dbo.webhook_endpoints
(
    id          UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    name        NVARCHAR(100) NOT NULL,
    url         NVARCHAR(2048) NOT NULL,
    secret      NVARCHAR(512) NULL,
    is_active   BIT NOT NULL DEFAULT 1,
    created_at  DATETIME2(7) NOT NULL DEFAULT SYSUTCDATETIME(),
    updated_at  DATETIME2(7) NOT NULL DEFAULT SYSUTCDATETIME()
);
